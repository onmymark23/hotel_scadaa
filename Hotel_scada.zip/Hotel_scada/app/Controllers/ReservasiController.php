<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use PhpParser\Node\Expr\Cast\Array_;

class ReservasiController extends BaseController
{
    public function index(){
        $currentPage = $this->request->getVar('page_reservasi') ? $this->request->getVar('page_reservasi') :1; 

        //d($this->request->getVar('keyword'));

        $keyword = $this->request->getVar('keyword');
        if($keyword){
            $datatamu = $this->reservasi->search($keyword);
        }else{
            $datatamu = $this->reservasi;    
        }

        $data = [
            'title'=> 'Berikut ini daftar Tamu yang sudah terdaftar dalam database.',
            'tamu' => $datatamu->paginate(10, 'reservasi'),
            'pager' => $this->reservasi->pager,
            'currentPage' => $currentPage
            ] ;
        return view('Reservasi/tampil', $data);
    }
    public function in($idreservasi){
        $datanya = ['status' => ['cek in']];
        $this->reservasi->update($idreservasi, $datanya);
    return redirect()->to(site_url('/reservasi/petugas'))->with('berhasil','Data berhasil diupdate');
    }

    public function out($idreservasi){
        $datanya = ['status' => ['cek out']];
        $this->reservasi->update($idreservasi, $datanya);
    return redirect()->to(site_url('/reservasi/petugas'))->with('berhasil','Data berhasil diupdate');

    }
    public function invoice($id_reservasi)
    {
        $reservasi = $this->reservasi
            ->select('tbl_reservasi.*, id_reservasi', 'id_kamar', 'nama_pemesan', 'email_pemesan','nama_tamu','no_telp','tgl_cek_in', 'tgl_cek_out', 'jumlah_kamar_dipensan')
             ->join('tbl_kamar', 'tbl_kamar.id_kamar = tbl_reservasi.id_kamar' )
            ->find($id_reservasi);
        $data['reservasi'] = $reservasi;

        $ckin = strtotime($reservasi['tgl_cek_in']);
        $ckout = strtotime($reservasi['tgl_cek_out']);
        return view('invoice', $data);
    }
    
}
