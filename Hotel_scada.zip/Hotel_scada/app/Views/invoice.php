<html>

<head>
	<style>
		table {
			font-family: arial, sans-serif;
			border-collapse: collapse;
			width: 100%;
		}

		td,
		th {
			border: 1px solid #000000;
			text-align: center;
			height: 20px;
			margin: 8px;
		}
	</style>
</head>

<body>
	<div style="font-size:40px; color:'#dddddd'"><i>Reservasi Hotel</i></div>
	<p>
		<i>markcity Hotel </i><br>
	</p>
	<hr>
	<hr>
	<p></p>
	<p>
		Pemesan : <?= $reservasi['nama_tamu'] ?><br>
		Email : <?= $reservasi['email_pemesan'] ?><br>
		Telepon : <?= $reservasi['no_telp'] ?><br>
		Transaksi No : <?= $reservasi['id_reservasi'] ?><br>
		Tanggal : <?= date('d-m-Y', strtotime($reservasi['tgl_cek_in'])) ?><br>
	</p>
	<table cellpadding="6">
		<tr>
			<th><strong> Kamar</strong></th>
			<th><strong>Jumlah kamar</strong></th>
			<th><strong>cek in</strong></th>
			<th><strong>cek out</strong></th>
		</tr>
		<tr>
			<td><?= $reservasi['id_kamar'] ?></td>
			<td><?= $reservasi['jumlah_kamar_dipensan'] ?></td>
			<td><?= $reservasi['tgl_cek_in'] ?></td>
			<td><?= $reservasi['tgl_cek_out'] ?></td>

		</tr>
	</table>
</body>


</html>