<footer class="footer mt-auto py-3"> 
  <div class="container">
<span class="text-muted">Silahkan cek in ya dear!</span> 
  </div>
</footer> 
<script src="/js/jquery-3.6.0.min.js"></script>
<script src="/js/bootstrap.min.js"></script> 
  </body>
</html> 

